package ma.fsr.tp1.cabinetMedical;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabinetMedicalTp1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
