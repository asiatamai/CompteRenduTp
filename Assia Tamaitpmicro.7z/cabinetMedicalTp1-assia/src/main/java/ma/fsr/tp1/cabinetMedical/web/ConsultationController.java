package ma.fsr.tp1.cabinetMedical.web;

import ma.fsr.tp1.cabinetMedical.model.Consultation;
import ma.fsr.tp1.cabinetMedical.service.IHospitalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class ConsultationController {

    @Autowired
    private IHospitalService hospitalService;

    @GetMapping("/consultations")
    public List<Consultation> getConsultations(){
        return hospitalService.getAllConsultations();
    }

    @PostMapping("/consultations")
    public Consultation saveConsultation(@RequestBody Consultation consultation){
        return hospitalService.saveConsultation(consultation);
    }
}