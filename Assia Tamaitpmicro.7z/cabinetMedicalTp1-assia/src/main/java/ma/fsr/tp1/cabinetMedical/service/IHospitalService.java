package ma.fsr.tp1.cabinetMedical.service;

import ma.fsr.tp1.cabinetMedical.model.Patient;
import ma.fsr.tp1.cabinetMedical.model.Medecin;
import ma.fsr.tp1.cabinetMedical.model.RendezVous;
import ma.fsr.tp1.cabinetMedical.model.Consultation;
import java.util.List;

public interface IHospitalService {
    Patient savePatient(Patient patient);
    Medecin saveMedecin(Medecin medecin);
    RendezVous saveRDV(RendezVous rendezVous);
    Consultation saveConsultation(Consultation consultation);
    List<Patient> getAllPatients();
    List<Medecin> getAllMedecins();
    List<RendezVous> getAllRDV();
    List<Consultation> getAllConsultations();
}
