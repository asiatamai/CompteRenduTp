package ma.fsr.tp1.cabinetMedical.web;

import ma.fsr.tp1.cabinetMedical.model.RendezVous;
import ma.fsr.tp1.cabinetMedical.service.IHospitalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class RendezVousController {

    @Autowired
    private IHospitalService hospitalService;


    @GetMapping("/rendezvous")
    public List<RendezVous> consultRendezVous() {
        return hospitalService.getAllRDV();
    }


    @PostMapping("/rendezvous")
    public RendezVous saveRendezVous(@RequestBody RendezVous rendezVous) {
        return hospitalService.saveRDV(rendezVous);
    }
}