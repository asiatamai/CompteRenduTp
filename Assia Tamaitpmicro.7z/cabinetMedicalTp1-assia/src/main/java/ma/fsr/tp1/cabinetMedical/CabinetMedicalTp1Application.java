package ma.fsr.tp1.cabinetMedical;

import ma.fsr.tp1.cabinetMedical.model.*;
import ma.fsr.tp1.cabinetMedical.service.IHospitalService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.LocalDate;
import java.util.Date;
import java.util.stream.Stream;

@SpringBootApplication
public class CabinetMedicalTp1Application {

    public static void main(String[] args) {
        SpringApplication.run(CabinetMedicalTp1Application.class, args);
    }

    @Bean
    CommandLineRunner start(IHospitalService hospitalService) {
        return args -> {

            Stream.of("Assia Tamai", "Mosaab", "Farah").forEach(name -> {
                Patient p = new Patient();
                p.setNom(name);
                p.setDateNaissance(LocalDate.of(2000, 1, 1));
                p.setGenre(Math.random() > 0.5 ? "M" : "F");
                hospitalService.savePatient(p);
            });

            Stream.of("Dr. Nekach", "Dr. Bouziane").forEach(name -> {
                Medecin m = new Medecin();
                m.setNom(name);
                m.setEmail(name.replaceAll(" ", "") + "@gmail.com");
                m.setSpecialite(Math.random() > 0.5 ? "Generaliste" : "Dentiste");
                hospitalService.saveMedecin(m);
            });


            Patient patient = hospitalService.getAllPatients().get(0);
            Medecin medecin = hospitalService.getAllMedecins().get(0);

            RendezVous rdv = new RendezVous();
            rdv.setDateRdv(new Date());
            rdv.setStatut("CONFIRME");
            rdv.setPatient(patient);
            rdv.setMedecin(medecin);


            hospitalService.saveRDV(rdv);

        };
    }
}