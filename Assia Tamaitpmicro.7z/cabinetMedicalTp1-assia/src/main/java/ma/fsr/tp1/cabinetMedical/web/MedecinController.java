package ma.fsr.tp1.cabinetMedical.web;

import ma.fsr.tp1.cabinetMedical.model.Medecin;
import ma.fsr.tp1.cabinetMedical.service.IHospitalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MedecinController {

    @Autowired
    private IHospitalService hospitalService;


    @GetMapping("/medecins")
    public List<Medecin> consultMedecins() {
        return hospitalService.getAllMedecins();
    }


    @PostMapping("/medecins")
    public Medecin saveMedecin(@RequestBody Medecin medecin) {
        return hospitalService.saveMedecin(medecin);
    }
}