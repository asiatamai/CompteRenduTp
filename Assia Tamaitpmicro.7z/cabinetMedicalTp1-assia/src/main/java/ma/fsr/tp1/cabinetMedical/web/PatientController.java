package ma.fsr.tp1.cabinetMedical.web;

import ma.fsr.tp1.cabinetMedical.model.Patient;
import ma.fsr.tp1.cabinetMedical.service.IHospitalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class PatientController {

    @Autowired
    private IHospitalService hospitalService;

    @GetMapping("/patients")
    public List<Patient> consultPatients(){
        return hospitalService.getAllPatients();
    }

    @PostMapping("/patients")
    public Patient savePatient(@RequestBody Patient patient){
        return hospitalService.savePatient(patient);
    }
}