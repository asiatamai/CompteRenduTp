package ma.fsr.tp1.cabinetMedical.repository;

import ma.fsr.tp1.cabinetMedical.model.Consultation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsultationRepository extends JpaRepository<Consultation, Long> {
}